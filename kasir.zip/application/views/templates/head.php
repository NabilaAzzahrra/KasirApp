<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MI20A</title>
<link rel="icon" href="https://idn-static-assets.s3-ap-southeast-1.amazonaws.com/school/10104.png" sizes="any">
<link rel="apple-touch-icon" href="<?= base_url('assets/dist/img/favicons/apple-touch-icon.png'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/dist/css/fonts.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/scrollbar/scrollbar.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/fontawesome-pro/css/all.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/select2/css/select2.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/dist/css/adminlte.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/chart.js/Chart.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/plugins/toastr/toastr.min.css'); ?>">