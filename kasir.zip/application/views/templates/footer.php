<footer class="main-footer">
	<strong>Copyright &copy; 2022 <a class="text-info" href="https://instagram.com/lp3i_ik20">MI20A</a>.</strong>
	All rights reserved.
	<div class="float-right d-none d-sm-inline-block">Kasir App</div>
</footer>
