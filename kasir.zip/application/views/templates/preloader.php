<div class="preloader flex-column justify-content-center align-items-center">
  <img class="animation__wobble" src="https://idn-static-assets.s3-ap-southeast-1.amazonaws.com/school/10104.png" alt="Kasir App" height="60" width="60">
</div>