# Kasir App

A **CodeIgniter 3** framework based web app for submission of my *"Web Framework Development"* final exam. Feature lists:

- Login page + validations.
- Session validations.
- Dashboard / homepage with chart and info cards.
- Profile page.
- User management page (access is for admins only).
- Cart for purchases and sales data input.
- Logout confirmation.
- ...and many more!

Any contributions (fixes, patches, improvements, code quality commits) are welcome! 😊

Credits to [AdminLTE](https://adminlte.io) for the front-end template.
